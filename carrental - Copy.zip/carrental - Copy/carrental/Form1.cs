namespace carrental
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                 string uname =  txtuname.Text;
                 string pass = txtpass.Text;

            if (uname.Equals("Admin")&& pass.Equals("123"))
            {
                Main m  = new Main();
                this.Hide();
                m.Show();


            }
            else
            {
                MessageBox.Show("Username or Password incorrect");
                txtuname.Clear();
                txtpass.Clear();
                txtuname.Focus();
            }



        }

        private void txtuname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}